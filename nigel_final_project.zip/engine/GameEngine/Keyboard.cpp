//
//  InputHandler.cpp
//  GameEngine
//
//  Created by David Lively on 2/22/16.
//  Copyright © 2016 David Lively. All rights reserved.
//

#include "InputHandler.h"

class InputHandler : public GameObject
{
public:
private:
    
};
